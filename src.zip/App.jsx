import { useState } from 'react';
import './App.css';
import Testimonial from './components/Testimonial';
import Photo1 from './images/profile1.jpg';
import Photo2 from './images/profile2.jpg';
import Photo3 from './images/profile3.jpg';
import Button from './components/Button';


function App(){
    
    const [theme, setTheme] = useState('light')

    function onClickFn(){
        if (theme == 'light'){
            setTheme('dark')
        } else{
            setTheme('light')
        }
    }

    return(
        <div className={'main-container ' + theme}>
            <Button
                onClickFn = {onClickFn}
                value = {theme == 'dark' ? 'ligth' : 'dark'}
            />
            <Testimonial
                img={Photo1} 
                name='Josefina Corro' 
                stars= '⭐⭐⭐⭐⭐'
                text= 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sint, repellat, dignissimos accusamus ipsa facere dicta voluptate provident maxime hic magnam quasi.'
            />
            <Testimonial
                img={Photo2} 
                name='Cristobal Gerez' 
                stars= '⭐⭐'
                text= 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sint, repellat, dignissimos accusamus ipsa facere dicta voluptate provident maxime hic magnam quasi.'
            />
            <Testimonial
                img={Photo3} 
                name='Jocco Design' 
                stars= '⭐⭐⭐'
                text= 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sint, repellat, dignissimos accusamus ipsa facere dicta voluptate provident maxime hic magnam quasi.'
            />
        </div>
    )
}

export default App;